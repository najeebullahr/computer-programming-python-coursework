# -*- coding: utf-8 -*-
"""
Created on Mon May 19 13:18:58 2025

@author: NuR
"""

