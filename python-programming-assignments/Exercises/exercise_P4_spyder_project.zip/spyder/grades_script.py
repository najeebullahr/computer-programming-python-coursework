# -*- coding: utf-8 -*-
"""
Created on Mon May 19 13:24:28 2025

@author: NuR
"""

import csv

# Data to write
data = [
    ['Student', 'Math', 'Science'],
    ['Ali', 85, 90],
    ['Sara', 78, 88],
    ['Najeeb', 92, 95]
]

# Save to CSV
with open(r'F:\spyder\grades.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

print("grades.csv file created.")
import csv

# Read the CSV and calculate averages
with open(r'F:\spyder\grades.csv', 'r') as file:
    reader = csv.DictReader(file)
    
    for row in reader:
        student = row['Student']
        math = float(row['Math'])
        science = float(row['Science'])
        average = (math + science) / 2
        
        print(f"{student}'s average grade: {average}")
