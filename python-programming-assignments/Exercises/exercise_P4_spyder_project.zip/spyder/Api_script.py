# -*- coding: utf-8 -*-
"""
Created on Mon May 19 13:39:56 2025

@author: NuR
"""

import requests

# Replace with your actual API key from OpenWeatherMap
API_KEY = "8163101505fed271a1ae99dd6764d9cd"
CITY = "Taipei"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

# Prepare the request URL
params = {
    'q': CITY,
    'appid': API_KEY,
    'units': 'metric'  # To get temperature in Celsius
}

# Send the GET request
response = requests.get(BASE_URL, params=params)

# Check response status
if response.status_code == 200:
    data = response.json()
    
    city_name = data['name']
    temperature = data['main']['temp']
    weather_description = data['weather'][0]['description']

    print(f"Weather in {city_name}")
    print(f"Temperature: {temperature}°C")
    print(f"Condition: {weather_description}")
else:
    print("Failed to retrieve weather data. Check your city name or API key.")
