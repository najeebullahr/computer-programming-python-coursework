# -*- coding: utf-8 -*-
"""
Created on Mon May 19 13:01:52 2025

@author: NuR
"""

